using Nexus.Blazor.Components;
using NexusCore;

namespace Nexus.Blazor
{
    public class WebProgram
    {
        public static void Main(string[] args)
        {
            //var builder = WebApplication.CreateBuilder(args);

            //// Add services to the container.
            //builder.Services.AddRazorComponents()
            //    .AddInteractiveServerComponents();

            //var app = builder.Build();

            //// Configure the HTTP request pipeline.
            //if (!app.Environment.IsDevelopment())
            //{
            //    app.UseExceptionHandler("/Error");
            //}

            //app.UseStaticFiles();
            //app.UseAntiforgery();

            //app.MapRazorComponents<App>()
            //    .AddInteractiveServerRenderMode();

            //app.Run();

            List<MenuItem> menuItem = MenuItem.getDefaultMenuStructure();

            var builder = new NexusBuilder()
                .setMainForm<MyMainForm>()
                //.setViewerForm<MyViewerForm>() // This is not implemented yet
                //.setEditorForm<MyEditorForm>() // This is not implemented yet
                .setMenuConfig(menuItem)
                .setUser("Q", "")
            ;

            NexusApp app = builder.Build();

            app.Run();

            app.CleanUp();
        }
    }
}
