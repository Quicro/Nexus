namespace Nexus.WindowsForms
{
    public partial class MyMainForm : Form
    {
        public MyMainForm()
        {
            InitializeComponent();
        }
    }
}
