namespace NexusCore.Interfaces {
    public interface IViewerForm : IControlledForm
    {



    }
}
