﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NexusCore.Interfaces.Widgets;

namespace NexusCore.Interfaces.AggregrateInterfaces.Controller
{
    internal interface IViewerWidget : IElementWidget
    {
    }
}
