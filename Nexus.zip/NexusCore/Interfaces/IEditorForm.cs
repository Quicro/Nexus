namespace NexusCore.Interfaces {
    public interface IEditorForm : IControlledForm
    {



    }
}
