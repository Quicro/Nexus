namespace NexusCore {
    public class NexusApp {
        public NexusApp() {
        }

        public void Destruct() {
        }
    }
}
